# 📷 Realistischer Bildgenerator

Erzeugt fotorealistische Bilder aus Text, lokal auf deinem Rechner, mit Open-Source-Diffusionsmodellen.

## Installation

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
# NVIDIA-GPU: passendes PyTorch zuerst installieren, z. B.
#   pip install torch --index-url https://download.pytorch.org/whl/cu124
pip install -r requirements.txt
```

Beim ersten Start wird das gewählte Modell von Hugging Face geladen (ca. 7 GB für SDXL-Modelle).
Für **FLUX.1 schnell** brauchst du ein Hugging-Face-Konto, musst die Lizenz auf der Modellseite akzeptieren
und dich mit `huggingface-cli login` anmelden.

## Benutzung

**Web-Oberfläche:**
```bash
python app.py            # dann http://127.0.0.1:7860 öffnen
```

**Kommandozeile:**
```bash
python cli.py "portrait of an old fisherman at a foggy harbor" --stil Porträt
python cli.py "a cozy cabin in snowy mountains" -m schnell -n 4 --seed 123
```

Die Bilder landen in `ausgabe/`. Prompt, Seed und Einstellungen sind in den PNG-Metadaten gespeichert,
so lässt sich jedes Bild exakt reproduzieren.

## Modelle

| Name | Modell | Stärke | Hardware |
|---|---|---|---|
| `fotorealistisch` | RealVisXL 4.0 | realistischste Fotos, Haut, Licht | GPU ab 8 GB VRAM / Apple Silicon |
| `schnell` | SDXL-Turbo | Ergebnis in 1–4 Schritten | geht auch auf der CPU (~30–60 s) |
| `flux` | FLUX.1 schnell | sehr gute Prompt-Treue und Details | GPU ab 12 GB (mit Offloading) |

## Tipps für mehr Realismus

- **Prompts auf Englisch** funktionieren deutlich besser.
- Konkret beschreiben: Motiv, Umgebung, Licht, Tageszeit, Kamera, z. B. *"golden hour, 85mm, shallow depth of field"*.
- Den passenden **Foto-Stil** wählen; er ergänzt automatisch fotografische Begriffe.
- Gefällt ein Bild, den **Seed** übernehmen und den Prompt nur leicht ändern.
- Guidance 4–6 und 25–35 Schritte sind für `fotorealistisch` ideal.

## Lizenzen

Die Modelle haben eigene Lizenzen: SDXL-Turbo ist nur für nicht-kommerzielle Nutzung freigegeben,
FLUX.1 schnell steht unter Apache 2.0, RealVisXL unter der SDXL-Lizenz (OpenRAIL++). Bitte vor kommerzieller Nutzung prüfen.

## Als Bildserver für andere Apps (z. B. Restekoch)

```bash
BILD_TOKEN=ein-langes-geheimes-passwort python server.py      # lauscht auf Port 8000
```
Windows (PowerShell): `$env:BILD_TOKEN="ein-langes-geheimes-passwort"; python server.py`

- `POST /bild` mit Header `Authorization: Bearer <BILD_TOKEN>` und JSON `{"prompt": "...", "stil": "Essen"}`
  liefert `{"bild": "data:image/jpeg;base64,..."}`.
- `GET /status` zeigt Modell und Gerät.
- Optional: `BILD_MODELL` (`schnell`, `fotorealistisch`, `flux`; Standard: mit GPU `fotorealistisch`, sonst `schnell`),
  `BILD_SPEICHERN=1` speichert jedes Bild zusätzlich in `ausgabe/`.

Damit eine App im Internet (z. B. Restekoch bei Vercel) den Server auf deinem Rechner erreicht, brauchst du eine
öffentliche Adresse, am einfachsten einen kostenlosen Cloudflare-Tunnel:
```bash
cloudflared tunnel --url http://localhost:8000
```
Die angezeigte `https://….trycloudflare.com`-Adresse trägst du in der App als Bildserver-Adresse ein.
