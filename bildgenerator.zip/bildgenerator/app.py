"""Web-Oberfläche für den Bildgenerator. Start: python app.py"""

from __future__ import annotations

import argparse

import gradio as gr

from generator import PRESETS, STANDARD_NEGATIV, STILE, Bildgenerator

generator = Bildgenerator()

BEISPIELE = [
    ["Porträt einer älteren Fischerin mit wettergegerbtem Gesicht an einem nebligen Hafen", "Porträt"],
    ["a misty alpine lake at sunrise surrounded by pine trees, reflections on the water", "Landschaft"],
    ["a luxury wristwatch on a black marble surface, water droplets", "Produkt"],
    ["a rainy night street in Tokyo, neon signs reflecting on wet asphalt, people with umbrellas", "Street"],
    ["a rustic sourdough bread on a wooden table with butter and rosemary", "Essen"],
]


def preset_geaendert(modell: str):
    p = PRESETS[modell]
    return (
        gr.update(value=p.width),
        gr.update(value=p.height),
        gr.update(value=p.steps),
        gr.update(value=p.guidance),
        gr.update(interactive=p.supports_negative),
        p.beschreibung,
    )


def erzeugen(prompt, modell, stil, negativ, breite, hoehe, schritte, guidance, seed, anzahl,
             progress=gr.Progress()):
    try:
        progress(0, desc=f"Lade Modell {PRESETS[modell].repo_id} (beim ersten Mal Download) …")
        ergebnisse = generator.erzeuge(
            prompt=prompt,
            modell=modell,
            stil=stil,
            negativ=negativ,
            breite=int(breite),
            hoehe=int(hoehe),
            schritte=int(schritte),
            guidance=float(guidance),
            seed=int(seed),
            anzahl=int(anzahl),
            fortschritt=progress,
        )
    except Exception as e:  # Fehler verständlich in der Oberfläche anzeigen
        raise gr.Error(f"{type(e).__name__}: {e}")
    bilder = [(r.bild, f"Seed {r.seed}") for r in ergebnisse]
    info = "\n".join(f"✔ {r.pfad}  (Seed {r.seed})" for r in ergebnisse)
    return bilder, info


def baue_oberflaeche() -> gr.Blocks:
    with gr.Blocks(title="Realistischer Bildgenerator") as demo:
        gr.Markdown(
            "# 📷 Realistischer Bildgenerator\n"
            f"Gerät: **{generator.geraet.upper()}** · Bilder werden in `{generator.ausgabe_ordner}/` gespeichert."
        )
        with gr.Row():
            with gr.Column(scale=1):
                prompt = gr.Textbox(label="Was soll zu sehen sein?", lines=3,
                                    placeholder="z. B. eine Katze auf einer Fensterbank im Morgenlicht")
                with gr.Row():
                    modell = gr.Dropdown(list(PRESETS), value="fotorealistisch", label="Modell")
                    stil = gr.Dropdown(list(STILE), value="Allgemeines Foto", label="Foto-Stil")
                modell_info = gr.Markdown(PRESETS["fotorealistisch"].beschreibung)
                knopf = gr.Button("Bild erzeugen", variant="primary", size="lg")

                with gr.Accordion("Erweiterte Einstellungen", open=False):
                    negativ = gr.Textbox(label="Negativ-Prompt (was vermieden werden soll)",
                                         value=STANDARD_NEGATIV, lines=3)
                    with gr.Row():
                        breite = gr.Slider(512, 1536, value=1024, step=64, label="Breite")
                        hoehe = gr.Slider(512, 1536, value=1024, step=64, label="Höhe")
                    with gr.Row():
                        schritte = gr.Slider(1, 60, value=30, step=1, label="Schritte")
                        guidance = gr.Slider(0.0, 12.0, value=5.0, step=0.5, label="Guidance (Prompt-Treue)")
                    with gr.Row():
                        seed = gr.Number(value=-1, precision=0, label="Seed (-1 = zufällig)")
                        anzahl = gr.Slider(1, 4, value=1, step=1, label="Anzahl Bilder")

            with gr.Column(scale=1):
                galerie = gr.Gallery(label="Ergebnis", columns=2, height=640, format="png")
                info = gr.Textbox(label="Gespeichert", lines=2, interactive=False)

        gr.Examples(BEISPIELE, inputs=[prompt, stil])

        modell.change(preset_geaendert, modell, [breite, hoehe, schritte, guidance, negativ, modell_info])
        eingaben = [prompt, modell, stil, negativ, breite, hoehe, schritte, guidance, seed, anzahl]
        knopf.click(erzeugen, eingaben, [galerie, info])
        prompt.submit(erzeugen, eingaben, [galerie, info])
    return demo


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Web-Oberfläche des Bildgenerators")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--share", action="store_true", help="öffentlichen Gradio-Link erzeugen")
    args = parser.parse_args()
    baue_oberflaeche().queue().launch(server_port=args.port, share=args.share)
