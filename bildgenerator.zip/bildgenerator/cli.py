"""Kommandozeile: python cli.py "ein Leuchtturm bei Sturm" --stil Landschaft"""

from __future__ import annotations

import argparse

from generator import PRESETS, STILE, Bildgenerator


def main() -> None:
    p = argparse.ArgumentParser(description="Erzeugt realistische Bilder aus Text.")
    p.add_argument("prompt", help="Beschreibung des Bildes (Englisch liefert meist die besten Ergebnisse)")
    p.add_argument("-m", "--modell", choices=list(PRESETS), default="fotorealistisch")
    p.add_argument("-s", "--stil", choices=list(STILE), default="Allgemeines Foto")
    p.add_argument("-n", "--anzahl", type=int, default=1)
    p.add_argument("--negativ", default=None, help="eigener Negativ-Prompt")
    p.add_argument("--breite", type=int)
    p.add_argument("--hoehe", type=int)
    p.add_argument("--schritte", type=int)
    p.add_argument("--guidance", type=float)
    p.add_argument("--seed", type=int, default=-1)
    p.add_argument("-o", "--ausgabe", default="ausgabe", help="Zielordner")
    a = p.parse_args()

    gen = Bildgenerator(a.ausgabe)
    print(f"Gerät: {gen.geraet} · Modell: {PRESETS[a.modell].repo_id}")
    for r in gen.erzeuge(a.prompt, modell=a.modell, stil=a.stil, negativ=a.negativ,
                         breite=a.breite, hoehe=a.hoehe, schritte=a.schritte,
                         guidance=a.guidance, seed=a.seed, anzahl=a.anzahl):
        print(f"✔ {r.pfad}  (Seed {r.seed})")


if __name__ == "__main__":
    main()
