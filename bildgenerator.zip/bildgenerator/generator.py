"""Kern des Bildgenerators: lädt Diffusionsmodelle und erzeugt fotorealistische Bilder."""

from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import torch
from PIL import Image
from PIL.PngImagePlugin import PngInfo

# ---------------------------------------------------------------------------
# Modell-Presets
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ModelPreset:
    repo_id: str
    beschreibung: str
    steps: int
    guidance: float
    width: int
    height: int
    supports_negative: bool
    variant: str | None = "fp16"
    extra_kwargs: dict = field(default_factory=dict)


PRESETS: dict[str, ModelPreset] = {
    # Fotorealistischer SDXL-Finetune – beste Qualität für Fotos, braucht ~8 GB VRAM
    "fotorealistisch": ModelPreset(
        repo_id="SG161222/RealVisXL_V4.0",
        beschreibung="RealVisXL 4.0 – sehr realistische Fotos (empfohlen mit GPU)",
        steps=30,
        guidance=5.0,
        width=1024,
        height=1024,
        supports_negative=True,
    ),
    # Distilliertes SDXL – 1–4 Schritte, läuft notfalls auch auf der CPU
    "schnell": ModelPreset(
        repo_id="stabilityai/sdxl-turbo",
        beschreibung="SDXL-Turbo – Ergebnis in 1–4 Schritten, auch auf CPU nutzbar",
        steps=4,
        guidance=0.0,
        width=512,
        height=512,
        supports_negative=False,
    ),
    # FLUX.1 schnell – sehr gute Prompt-Treue, braucht viel Speicher (Offloading aktiv)
    "flux": ModelPreset(
        repo_id="black-forest-labs/FLUX.1-schnell",
        beschreibung="FLUX.1 schnell – exzellente Details & Text, braucht starke GPU",
        steps=4,
        guidance=0.0,
        width=1024,
        height=1024,
        supports_negative=False,
        variant=None,
        extra_kwargs={"max_sequence_length": 256},
    ),
}

# ---------------------------------------------------------------------------
# Foto-Stile: Prompt-Bausteine, die den Realismus deutlich steigern
# ---------------------------------------------------------------------------

STILE: dict[str, str] = {
    "Keiner": "",
    "Allgemeines Foto": (
        "RAW photo, photorealistic, highly detailed, sharp focus, natural lighting, "
        "shot on Canon EOS R5, 35mm lens, f/2.8, film grain"
    ),
    "Porträt": (
        "RAW portrait photo, photorealistic, detailed skin texture, visible pores, "
        "natural skin tones, soft window light, shot on Sony A7R IV, 85mm lens, f/1.8, "
        "shallow depth of field, bokeh, catchlights in the eyes"
    ),
    "Landschaft": (
        "landscape photography, photorealistic, golden hour, dramatic sky, ultra detailed, "
        "shot on Nikon Z7, 16-35mm wide angle lens, f/11, HDR, crisp details"
    ),
    "Produkt": (
        "professional product photography, studio lighting, softbox, clean background, "
        "photorealistic, sharp focus, commercial photo, 100mm macro lens"
    ),
    "Street": (
        "candid street photography, photorealistic, natural light, documentary style, "
        "shot on Leica M11, 35mm lens, film grain, authentic atmosphere"
    ),
    "Essen": (
        "food photography, photorealistic, appetizing, soft natural light, shallow depth "
        "of field, overhead shot, styled table, 50mm lens"
    ),
    "Architektur": (
        "architectural photography, photorealistic, straight vertical lines, tilt-shift lens, "
        "blue hour, highly detailed, wide angle"
    ),
}

STANDARD_NEGATIV = (
    "cartoon, anime, illustration, painting, drawing, 3d render, cgi, plastic skin, "
    "doll, deformed, disfigured, bad anatomy, extra fingers, mutated hands, blurry, "
    "lowres, jpeg artifacts, oversaturated, overexposed, watermark, text, signature"
)


def baue_prompt(prompt: str, stil: str) -> str:
    zusatz = STILE.get(stil, "")
    prompt = prompt.strip().rstrip(",")
    return f"{prompt}, {zusatz}" if zusatz else prompt


# ---------------------------------------------------------------------------
# Hardware
# ---------------------------------------------------------------------------


def waehle_geraet() -> tuple[str, torch.dtype]:
    if torch.cuda.is_available():
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        return "cuda", dtype
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps", torch.float16
    # SDXL braucht in float32 ~14 GB RAM; bei weniger Speicher bfloat16 nutzen (halber Bedarf)
    try:
        ram_gb = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024**3
    except (ValueError, OSError, AttributeError):
        ram_gb = 0
    return "cpu", torch.float32 if ram_gb >= 24 else torch.bfloat16


# ---------------------------------------------------------------------------
# Generator
# ---------------------------------------------------------------------------


@dataclass
class Ergebnis:
    bild: Image.Image
    seed: int
    pfad: Path | None
    metadaten: dict


class Bildgenerator:
    def __init__(self, ausgabe_ordner: str | Path = "ausgabe"):
        self.ausgabe_ordner = Path(ausgabe_ordner)
        self.geraet, self.dtype = waehle_geraet()
        self._pipe = None
        self._preset_name: str | None = None

    # -- Laden ---------------------------------------------------------------

    def lade(self, preset_name: str):
        if self._pipe is not None and self._preset_name == preset_name:
            return self._pipe
        if preset_name not in PRESETS:
            raise ValueError(f"Unbekanntes Modell '{preset_name}'. Verfügbar: {', '.join(PRESETS)}")

        from diffusers import AutoPipelineForText2Image, DPMSolverMultistepScheduler

        preset = PRESETS[preset_name]
        self._pipe = None  # alten Speicher freigeben
        if self.geraet == "cuda":
            torch.cuda.empty_cache()

        kwargs = {"torch_dtype": self.dtype, "use_safetensors": True}
        if preset.variant:
            # fp16-Dateien sind halb so groß; auf der CPU werden sie beim Laden in float32 umgewandelt
            kwargs["variant"] = preset.variant

        try:
            pipe = AutoPipelineForText2Image.from_pretrained(preset.repo_id, **kwargs)
        except (OSError, ValueError):
            # Manche Repos haben keine fp16-Variante -> ohne variant erneut versuchen
            kwargs.pop("variant", None)
            pipe = AutoPipelineForText2Image.from_pretrained(preset.repo_id, **kwargs)

        # DPM++ 2M Karras liefert bei SDXL-Fotomodellen die realistischsten Ergebnisse
        if preset_name == "fotorealistisch":
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(
                pipe.scheduler.config, use_karras_sigmas=True, algorithm_type="dpmsolver++"
            )

        if self.geraet == "cuda":
            vram_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
            if preset_name == "flux" or vram_gb < 10:
                pipe.enable_model_cpu_offload()  # spart VRAM
            else:
                pipe.to("cuda")
        else:
            pipe.to(self.geraet)

        if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_tiling"):
            pipe.vae.enable_tiling()  # große Auflösungen ohne Speicherüberlauf

        self._pipe, self._preset_name = pipe, preset_name
        return pipe

    # -- Erzeugen ------------------------------------------------------------

    def erzeuge(
        self,
        prompt: str,
        modell: str = "fotorealistisch",
        stil: str = "Allgemeines Foto",
        negativ: str | None = None,
        breite: int | None = None,
        hoehe: int | None = None,
        schritte: int | None = None,
        guidance: float | None = None,
        seed: int | None = None,
        anzahl: int = 1,
        speichern: bool = True,
        fortschritt=None,
    ) -> list[Ergebnis]:
        if not prompt or not prompt.strip():
            raise ValueError("Bitte einen Prompt eingeben.")

        preset = PRESETS[modell]
        pipe = self.lade(modell)

        breite = _auf_vielfaches(breite or preset.width)
        hoehe = _auf_vielfaches(hoehe or preset.height)
        schritte = int(schritte or preset.steps)
        guidance = preset.guidance if guidance is None else float(guidance)
        voller_prompt = baue_prompt(prompt, stil)
        negativ = STANDARD_NEGATIV if negativ is None else negativ
        if seed is None or seed < 0:
            seed = random.randint(0, 2**32 - 1)

        ergebnisse = []
        for i in range(max(1, int(anzahl))):
            aktueller_seed = (seed + i) % 2**32
            generator = torch.Generator("cpu").manual_seed(aktueller_seed)

            aufruf = dict(
                prompt=voller_prompt,
                width=breite,
                height=hoehe,
                num_inference_steps=schritte,
                guidance_scale=guidance,
                generator=generator,
                **preset.extra_kwargs,
            )
            if preset.supports_negative and guidance > 1.0 and negativ:
                aufruf["negative_prompt"] = negativ
            if fortschritt is not None:
                aufruf["callback_on_step_end"] = _callback(fortschritt, i, anzahl, schritte)

            bild = pipe(**aufruf).images[0]

            meta = {
                "prompt": prompt,
                "voller_prompt": voller_prompt,
                "negativ_prompt": aufruf.get("negative_prompt", ""),
                "modell": preset.repo_id,
                "stil": stil,
                "seed": aktueller_seed,
                "schritte": schritte,
                "guidance": guidance,
                "groesse": f"{breite}x{hoehe}",
            }
            pfad = self._speichere(bild, meta) if speichern else None
            ergebnisse.append(Ergebnis(bild=bild, seed=aktueller_seed, pfad=pfad, metadaten=meta))
        return ergebnisse

    def _speichere(self, bild: Image.Image, meta: dict) -> Path:
        self.ausgabe_ordner.mkdir(parents=True, exist_ok=True)
        zeit = datetime.now().strftime("%Y%m%d_%H%M%S")
        pfad = self.ausgabe_ordner / f"{zeit}_{meta['seed']}.png"
        info = PngInfo()
        info.add_text("parameters", json.dumps(meta, ensure_ascii=False))
        bild.save(pfad, pnginfo=info)
        return pfad


def _auf_vielfaches(wert: int, basis: int = 64) -> int:
    return max(basis, int(round(wert / basis)) * basis)


def _callback(fortschritt, index: int, anzahl: int, schritte: int):
    def cb(pipe, step, timestep, callback_kwargs):
        gesamt = (index * schritte + step + 1) / (anzahl * schritte)
        fortschritt(gesamt, desc=f"Bild {index + 1}/{anzahl} – Schritt {step + 1}/{schritte}")
        return callback_kwargs

    return cb
