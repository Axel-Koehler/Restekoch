"""HTTP-Schnittstelle des Bildgenerators, z. B. für Restekoch.

Start:   BILD_TOKEN=geheim python server.py
Anfrage: POST /bild  (Header "Authorization: Bearer geheim")
         {"prompt": "creamy pasta with spinach", "stil": "Essen"}
Antwort: {"bild": "data:image/jpeg;base64,...", "seed": 123, "sekunden": 14.2}
"""

from __future__ import annotations

import argparse
import base64
import hmac
import io
import os
import secrets
import threading
import time

import uvicorn
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

from generator import PRESETS, STILE, Bildgenerator

generator = Bildgenerator(os.environ.get("BILD_AUSGABE", "ausgabe"))
# Standard: mit GPU das fotorealistische Modell, sonst das schnelle
MODELL = os.environ.get("BILD_MODELL") or ("fotorealistisch" if generator.geraet != "cpu" else "schnell")
GROESSE = {"fotorealistisch": (1216, 832), "flux": (1216, 832), "schnell": (768, 512)}
TOKEN = os.environ.get("BILD_TOKEN", "")
SPEICHERN = os.environ.get("BILD_SPEICHERN", "0") == "1"
sperre = threading.Lock()  # immer nur ein Bild gleichzeitig – schont den Speicher

app = FastAPI(title="Bildgenerator-API", docs_url=None, redoc_url=None)


class Anfrage(BaseModel):
    prompt: str = Field(..., min_length=3, max_length=600)
    stil: str = "Essen"
    seed: int = -1


def pruefe_token(authorization: str | None) -> None:
    gesendet = (authorization or "").removeprefix("Bearer ").strip()
    if not TOKEN or not hmac.compare_digest(gesendet.encode(), TOKEN.encode()):
        raise HTTPException(status_code=401, detail="Token fehlt oder ist falsch.")


@app.get("/status")
def status():
    return {"ok": True, "modell": MODELL, "geraet": generator.geraet, "beschaeftigt": sperre.locked()}


@app.post("/bild")
def bild(anfrage: Anfrage, authorization: str | None = Header(default=None)):
    pruefe_token(authorization)
    stil = anfrage.stil if anfrage.stil in STILE else "Essen"
    if not sperre.acquire(timeout=90):
        raise HTTPException(status_code=503, detail="Der Bildgenerator ist gerade ausgelastet.")
    try:
        start = time.time()
        breite, hoehe = GROESSE.get(MODELL, (768, 512))
        ergebnis = generator.erzeuge(
            anfrage.prompt, modell=MODELL, stil=stil, breite=breite, hoehe=hoehe,
            seed=anfrage.seed, speichern=SPEICHERN,
        )[0]
    finally:
        sperre.release()

    puffer = io.BytesIO()
    ergebnis.bild.convert("RGB").save(puffer, format="JPEG", quality=85, optimize=True)
    daten = base64.b64encode(puffer.getvalue()).decode()
    return {"bild": f"data:image/jpeg;base64,{daten}", "seed": ergebnis.seed,
            "sekunden": round(time.time() - start, 1)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="HTTP-Schnittstelle des Bildgenerators")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=8000)
    a = p.parse_args()

    if MODELL not in PRESETS:
        raise SystemExit(f"BILD_MODELL '{MODELL}' unbekannt. Verfügbar: {', '.join(PRESETS)}")
    if not TOKEN:
        TOKEN = secrets.token_urlsafe(24)
        print(f"\nKein BILD_TOKEN gesetzt. Zufälliger Token für diesen Start:\n  {TOKEN}\n")
    print(f"Lade Modell '{MODELL}' auf {generator.geraet} …")
    generator.lade(MODELL)  # einmal vorab laden, damit die erste Anfrage nicht ewig dauert
    print(f"Bereit: http://{a.host}:{a.port}/bild")
    uvicorn.run(app, host=a.host, port=a.port)
